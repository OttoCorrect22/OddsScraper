from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import pandas as pd
from tabulate import tabulate

# Replace this URL with the one you want to scrape
url = "https://www.sportsline.com/nba/odds/"

# Initialize the web driver
driver = webdriver.Chrome()

# Navigate to the website
driver.get(url)
wait = WebDriverWait(driver, 10)

# Locate the elements using the provided XPath expression
date_elements = driver.find_elements(By.XPATH, '//*[contains(concat( " ", @class, " " ), concat( " ", "lhtruf", " " ))]')
away_name = driver.find_elements(By.XPATH, '//*[contains(concat( " ", @class, " " ), concat( " ", "away-team", " " ))]//*[contains(concat( " ", @class, " " ), concat( " ", "bAyIat", " " ))]')
away_record = driver.find_elements(By.XPATH, '//*[contains(concat( " ", @class, " " ), concat( " ", "away-team", " " ))]//*[contains(concat( " ", @class, " " ), concat( " ", "matchup", " " ))]//span[(((count(preceding-sibling::*) + 1) = 2) and parent::*)]')
home_name = driver.find_elements(By.XPATH, '//*[contains(concat( " ", @class, " " ), concat( " ", "home-team", " " ))]//*[contains(concat( " ", @class, " " ), concat( " ", "bAyIat", " " ))]')
home_record = driver.find_elements(By.XPATH, '//*[contains(concat( " ", @class, " " ), concat( " ", "home-team", " " ))]//*[contains(concat( " ", @class, " " ), concat( " ", "matchup", " " ))]//span[(((count(preceding-sibling::*) + 1) = 2) and parent::*)]')

# Create a DataFrame with the scraped data
data = {'Away Team': [],
        'Away Record': [],
        'Home Team': [],
        'Home Record': [],
        'Date': [],
        }

for date_element, away_name_element, away_record_element, home_name_element, home_record_element in zip(date_elements, away_name, away_record, home_name, home_record):
    data['Away Team'].append(away_name_element.text)
    data['Away Record'].append(away_record_element.text)
    data['Home Team'].append(home_name_element.text)
    data['Home Record'].append(home_record_element.text)
    data['Date'].append(date_element.text)

df = pd.DataFrame(data)

# Print the DataFrame
print(tabulate(df, headers="keys", tablefmt="grid"))

# Close the driver
driver.quit()